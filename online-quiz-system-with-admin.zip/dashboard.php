<?php
session_start();
if(!isset($_SESSION['user'])){
header("Location: login.php");
}
?>

<h2>User Dashboard</h2>
<a href="quiz.php">Start Quiz</a><br><br>
<a href="logout.php">Logout</a>