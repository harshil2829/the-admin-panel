# Online Quiz System with Admin Panel

## Features
- User Login/Register
- Quiz System
- Admin Panel
- Add/Delete Questions

## Admin Login
Username: admin
Password: admin123

## Run
1. Import database.sql
2. Put folder in htdocs
3. Open login.php
