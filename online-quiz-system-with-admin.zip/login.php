<?php
session_start();
include("config/db.php");

if(isset($_POST['login'])){
$email=$_POST['email'];
$pass=$_POST['password'];

$q="SELECT * FROM users WHERE email='$email' AND password='$pass'";
$res=mysqli_query($conn,$q);

if(mysqli_num_rows($res)>0){
$_SESSION['user']=$email;
header("Location: dashboard.php");
}else{
echo "Invalid Login";
}
}
?>

<form method="POST">
<h2>User Login</h2>
<input name="email" required><br><br>
<input type="password" name="password" required><br><br>
<button name="login">Login</button>
</form>